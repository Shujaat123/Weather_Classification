%% Author: Shujaat Khan
% dataset builder script for weather classifcation from natural color image

clc
clear all
close all

db_dir = ['dataset'];
classes = {'cloudy', 'rain', 'shine', 'sunrise'};
img_size = [256 256];

for class = 1:numel(classes)
    images.input=[];
    images.label=[];
    
im_list=dir([db_dir,'/',classes{class},'*']);
im_count(class)= numel(im_list);

    imgs = [];
    labels = [];
    for ind = 1:numel(im_list)
    im_path = [db_dir,'/',im_list(ind).name];
    tmp_img = imread(im_path);
    %%%
    if size(tmp_img,4)==3
            tmp_img = squeeze(tmp_img(:,:,1,:));
    end    
    if size(tmp_img,3)<3
        tmp_img(:,:,2)=tmp_img(:,:,1);
        tmp_img(:,:,3)=tmp_img(:,:,1);
    end
    %%%%
    tmp_img = imresize(tmp_img,[img_size]);
    tmp_label = class;

    imgs = cat(4,imgs,tmp_img);
    labels = cat(1,labels,tmp_label);
    end
    images.input = cat(1,images.input,permute(imgs,[4,3,2,1]));
    images.label = cat(4,images.label,permute(labels,[4,3,2,1]));
    save(['WeatherClassificationDB_',classes{class},'.mat'],'images','-v7.3')
end




